public class ticketingcli {
//    public static void main(String[] args) {
//        String json = """
//            {
//              "totalTickets": 800,
//              "ticketReleaseRate": 790,
//              "customerRetrievalRate": 780,
//              "maxTicketCapacity": 800
//            }
//        """;
//
//        try {
//            HttpRequest request = HttpRequest.newBuilder()
//                    .uri(new URI("http://localhost:8080/api/ticketing/start"))
//                    .header("Content-Type", "application/json")
//                    .POST(BodyPublishers.ofString(json))
//                    .build();
//
//            HttpClient client = HttpClient.newHttpClient();
//            HttpResponse<String> response = client.send(request, HttpResponse.BodyHandlers.ofString());
//
//            System.out.println("Response: " + response.body());
//        } catch (Exception e) {
//            e.printStackTrace();
//        }
//    }
}