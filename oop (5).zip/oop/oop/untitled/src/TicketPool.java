public class TicketPool {
    private int availableTickets;
    private int maxTicketCapacity;

    // Constructor
    public TicketPool(int maxTicketCapacity) {
        this.maxTicketCapacity = maxTicketCapacity;
        this.availableTickets = 0;  // Initially no tickets in the pool
    }

    // Method to get the available tickets
    public int getAvailableTickets() {
        return availableTickets;
    }

    // Method to get the maximum ticket capacity
    public int getMaxCapacity() {
        return maxTicketCapacity;
    }

    // Method to add tickets to the pool
    public synchronized void addTickets(int ticketReleaseRate) {
        // Ensure that we don't exceed the max capacity
        if (availableTickets + ticketReleaseRate <= maxTicketCapacity) {
            availableTickets += ticketReleaseRate;
            Logger.system("Added " + ticketReleaseRate + " tickets. Total tickets: " + availableTickets);
        } else {
            // If adding would exceed max capacity, only add up to the max capacity
            int ticketsToAdd = maxTicketCapacity - availableTickets;
            availableTickets = maxTicketCapacity;
            Logger.system("Added " + ticketsToAdd + " tickets. Reached max capacity: " + availableTickets);
        }
    }

    // Method to remove tickets from the pool
    public synchronized void removeTicket(int retrievalRate) {
        if (availableTickets >= retrievalRate) {
            availableTickets -= retrievalRate;
            Logger.system("Removed " + retrievalRate + " tickets. Remaining tickets: " + availableTickets);
        } else {
            // If there are not enough tickets, take all available tickets
            availableTickets = 0;
            Logger.system("Removed all available tickets. Remaining tickets: " + availableTickets);
        }
    }
}