import java.io.FileWriter;
import java.io.IOException;
import java.io.PrintWriter;

public class Logger {
    private static final String LOG_FILE = "Ticketing_System.log";
    private static final String LOG_FILE1 = "Ticketing_Inputs.log";

    public static synchronized void system(String message) {
        System.out.println(message); // Log to console
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE, true))) {
            writer.println(message); // Log to system log file
        } catch (IOException e) {
            System.err.println("Error writing to log file: " + e.getMessage());
        }
    }

    public static synchronized void userInput(String input) {
        System.out.println(input); // Log to console
        try (PrintWriter writer = new PrintWriter(new FileWriter(LOG_FILE1, true))) {
            writer.println(input); // Log to input log file
        } catch (IOException e) {
            System.err.println("Error writing to input log file: " + e.getMessage());
        }
    }
}