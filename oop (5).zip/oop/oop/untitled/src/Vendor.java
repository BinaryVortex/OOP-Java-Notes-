public class Vendor implements Runnable {
    private int vendorId;
    private int ticketReleaseRate;
    private final TicketPool ticketPool;

    public Vendor(int vendorId, int ticketReleaseRate, TicketPool ticketPool) {
        this.vendorId = vendorId;
        this.ticketReleaseRate = ticketReleaseRate;
        this.ticketPool = ticketPool;
    }

    @Override
    public void run() {
        try {
            while (ticketReleaseRate > 0) {
                // Releasing tickets
                releaseTickets();
                Thread.sleep(1000);  // the timegap
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void releaseTickets() {
        if (ticketPool.getAvailableTickets() + ticketReleaseRate <= ticketPool.getMaxCapacity()) {
            ticketPool.addTickets(ticketReleaseRate);
            Logger.system("[Vendor " + vendorId + "] added " + ticketReleaseRate + " tickets.");
        }
    }

    public void decreaseRate() {
        if (ticketReleaseRate > 0) {
            ticketReleaseRate--;
        }
    }

    public int getTicketReleaseRate() {
        return ticketReleaseRate;
    }
}