public class Customer implements Runnable {
    private int customerId;
    private int retrievalRate;
    private TicketPool ticketpool;

    public Customer(int customerId, int retrievalRate, TicketPool ticketPool) {
        this.customerId = customerId;
        this.retrievalRate = retrievalRate;
        this.ticketpool = ticketPool;
    }

    @Override
    public void run() {
        try {
            while (retrievalRate > 0) {
                // Retrieving tickets
                retrieveTickets();
                Thread.sleep(1000);  // The timegap
            }
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
        }
    }

    public void retrieveTickets() {
        if (ticketpool.getAvailableTickets() >= retrievalRate) {
            ticketpool.removeTicket(retrievalRate);
            Logger.system("[Customer " + customerId + "] retrieved " + retrievalRate + " tickets.");
        }
    }

    public void decreaseRate() {
        if (retrievalRate > 0) {
            retrievalRate--;
        }
    }

    public int getCustomerRetrievalRate() {
        return retrievalRate;
    }
}