import java.util.Scanner;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class Main {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        try {
            // Welcome message
            Logger.system("Welcome to the Ticketing System!");

            // User inputs
            int totalTickets = getPositiveInt(scanner, "Enter total number of tickets:", "Total tickets: ");
            int ticketReleaseRate = getPositiveInt(scanner, "Enter ticket release rate (tickets per second):", "Ticket release rate: ");
            int customerRetrievalRate = getPositiveInt(scanner, "Enter customer retrieval rate (tickets per second):", "Customer retrieval rate: ");
            int maxTicketCapacity = getPositiveInt(scanner, "Enter maximum ticket capacity:", "Maximum ticket capacity: ");

            // Create configuration object
            Configuration config = new Configuration(totalTickets, ticketReleaseRate, customerRetrievalRate, maxTicketCapacity);
            if (!config.validate()) {
                Logger.system("Invalid configuration. Exiting...");
                return;
            }

            // Initializing the TicketPool
            TicketPool ticketPool = new TicketPool(config.getMaxTicketCapacity());

            // Creating vendors and customers
            Vendor vendor1 = new Vendor(1, config.getTicketReleaseRate(), ticketPool);
            Vendor vendor2 = new Vendor(2, config.getTicketReleaseRate(), ticketPool);
            Customer customer1 = new Customer(1, config.getCustomerRetrievalRate(), ticketPool);
            Customer customer2 = new Customer(2, config.getCustomerRetrievalRate(), ticketPool);

            // Start threads with ExecutorService
            ExecutorService executor = Executors.newFixedThreadPool(4);
            executor.execute(vendor1);
            executor.execute(vendor2);
            executor.execute(customer1);
            executor.execute(customer2);

            // Tickets are running for 20 times
            for (int i = 0; i < 20; i++) {
                Logger.system("Round " + (i + 1) + ":");
                Logger.system("Total Tickets: " + config.getTotalTickets());
                Logger.system("Vendor release rate: " + vendor1.getTicketReleaseRate() + " tickets/second");
                Logger.system("Customer retrieval rate: " + customer1.getCustomerRetrievalRate() + " tickets/second");
                Logger.system("Maximum Ticket Capacity: " + config.getMaxTicketCapacity() + " tickets");

                // Let vendors release tickets
                vendor1.releaseTickets();
                vendor2.releaseTickets();

                // Let customers retrieve tickets
                customer1.retrieveTickets();
                customer2.retrieveTickets();

                // Minimize vendor and customer rates
                vendor1.decreaseRate();
                vendor2.decreaseRate();
                customer1.decreaseRate();
                customer2.decreaseRate();

                // The timegap
                Thread.sleep(1000);
            }

            executor.shutdownNow(); // stopping the executor
            Logger.system("All Tickets Have been Sold, System Ended");
        } catch (InterruptedException e) {
            Thread.currentThread().interrupt();
            Logger.system("Main thread interrupted: " + e.getMessage());
        }
    }

    // Method to get a positive integer from the user
    private static int getPositiveInt(Scanner scanner, String prompt, String label) {
        int value;
        while (true) {
            Logger.system(prompt); // Log prompt to system log
            try {
                value = Integer.parseInt(scanner.nextLine()); // Read user input
                Logger.userInput(label + value); // Log input to input log with label
                if (value > 0) {
                    break;
                } else {
                    Logger.system("Please enter a positive number.");
                }
            } catch (NumberFormatException e) {
                Logger.system("Invalid input. Please enter a positive integer.");
            }
        }
        return value;
    }
}